const Welcome = () => {
  return (
    <div>
      <h1>Welcome Admin</h1>
    </div>
  );
};

export default Welcome;
