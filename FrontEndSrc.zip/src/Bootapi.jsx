const base_url = "http://localhost:8080/spring-mvc-boot";

export default base_url;
